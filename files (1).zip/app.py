"""Gradio app for Oral Disease Image Classification (fine-tuned MobileNetV2).

Run locally:   python app.py
Needs:         final_model.keras in the same folder (exported from the notebook).
"""
import numpy as np
import tensorflow as tf
import gradio as gr

MODEL_PATH = "final_model.keras"
IMG_SIZE = 224
CLASSES = ["Calculus", "Caries", "Gingivitis", "Hypodontia", "Mouth Ulcer", "Tooth Discoloration"]

model = tf.keras.models.load_model(MODEL_PATH)


def predict(img):
    if img is None:
        return None
    arr = np.array(img.convert("RGB"), dtype="float32")
    arr = tf.image.resize(arr, (IMG_SIZE, IMG_SIZE))  # preprocessing is built into the model
    probs = model.predict(tf.expand_dims(arr, 0), verbose=0)[0]
    return {c: float(p) for c, p in zip(CLASSES, probs)}


HEADER = """
# 🦷 Oral Diseases Image Classification
Upload a photo of the mouth or teeth, and the AI will predict the most likely condition.

**Detectable conditions:** Calculus · Caries · Gingivitis · Hypodontia · Mouth Ulcer · Tooth Discoloration
"""

ABOUT = """
**Model:** MobileNetV2 (transfer learning + fine-tuning)

⚠️ *Student project for educational purposes only. Not a medical diagnosis. Please consult a dentist.*
"""

with gr.Blocks(theme=gr.themes.Soft(primary_hue="teal")) as demo:
    gr.Markdown(HEADER)
    with gr.Row():
        with gr.Column():
            inp = gr.Image(label="Upload an image", type="pil", height=350)
            with gr.Row():
                clear = gr.ClearButton(value="Clear")
                btn = gr.Button("🔍 Analyze", variant="primary")
        with gr.Column():
            out = gr.Label(num_top_classes=3, label="Prediction")
    gr.Markdown(ABOUT)

    btn.click(predict, inp, out)
    clear.add([inp, out])

if __name__ == "__main__":
    demo.launch()
